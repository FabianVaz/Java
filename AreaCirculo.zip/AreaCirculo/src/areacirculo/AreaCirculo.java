/* Haz una aplicación que calcule el área de un circulo(PI*R2). El radio se perdira por
 * teclado. Usa la constante Math.PI y el método pow de Math
 * Luis Fabián Vázquez Rodríguez | 20460323
 */
package areacirculo;
import java.util.*;
public class AreaCirculo {
    public static void main(String[] args) {
        // calcule el área de un circulo(PI*R2)
        double radio, area;
        Scanner Leer= new Scanner (System.in);
        System.out.println("Registre el radio del círculo");
        radio= Leer.nextDouble();
        area=Math.PI*Math.pow(radio, 2);
        System.out.println("El área del círculo es "+area+"u2");
    }

}
